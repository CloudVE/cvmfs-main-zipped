== fastq-join Galaxy Wrapper ==

This is a Galaxy wrapper for the fastq-join tool from ea-utils suite.

** Installation **

Installation from a tool shed provides the necessary tool dependencies.

Otherwise, make sure fastq-join is in the path.
Move the test data files to your galaxy root test-data.
Move the xml files to a subdirectory of your tools directory and add lines in tool_conf.xml to point to them.
Restart the Galaxy server.

** Attribution **

The ea-utils package and associated documentation can be found at: http://code.google.com/p/ea-utils/

The galaxy wrapper code was written by Lance Parsons (lparsons@princeton.edu), Lewis-Sigler Institute for Integrative Genomics, Princeton University.
